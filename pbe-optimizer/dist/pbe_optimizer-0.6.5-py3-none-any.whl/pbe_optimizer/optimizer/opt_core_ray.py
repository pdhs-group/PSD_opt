# -*- coding: utf-8 -*-
"""
Calculate the difference between the PSD of the simulation results and the experimental data.
Minimize the difference by optimization algorithm to obtain the kernel of PBE.
"""
import os, csv, time
from pathlib import Path
import yappi
from copy import deepcopy
from ray import tune
from .opt_core import OptCore
        
class OptCoreRay(OptCore, tune.Trainable):
    """
    An extension of the OptCore class that integrates with Ray Tune for optimization.

    This class inherits from both OptCore and tune.Trainable, making it a Ray Tune actor 
    for managing optimization iterations. It allows for the running of the PBE calculation 
    with Ray Tune's iterative optimization framework, and implements the necessary methods 
    to handle Ray Tune's checkpointing, configuration resetting, and optimization step control.

    Attributes
    ----------
    reuse_num : int
        A counter tracking the number of times the Actor has been reused.
    actor_wait : bool
        A flag indicating whether the actor should wait between iterations if the execution 
        time is too short.
    """
    def __init__(self, *args, **kwargs):
        # Initialize tune.Trainable to prepare the class as a Ray Tune actor
        OptCore.__init__(self)
        tune.Trainable.__init__(self, *args, **kwargs)
        
    def setup(self, config, core_params, pop_params, data_path):
        """
        Set up the environment for the optimization task.
        
        This method initializes the core attributes and PBE solver for optimization. It also 
        stores the experimental data and known parameters for use during the optimization process.
        
        Parameters
        ----------
        config : dict
            The configuration dictionary used by Ray Tune to pass in optimization parameters.
        core_params : dict
            The core parameters used for setting up the OptCore.
        pop_params : dict
            The parameters for the PBE.
        data_path : str
            The path to the experimental data.
        x_uni_exp : array-like
            The unique particle diameters in experimental data.
        data_exp : array-like
            The experimental PSD data.
        known_params : dict
            A dictionary of known parameters that will be used to override any conflicting 
            optimization parameters.
        """
        # Initialize OptCore attributes and PBE setup
        self.init_attr(core_params)
        self.init_pbe(pop_params, data_path)
        
        self.exp_data_paths = config.get("__exp_paths", None)
        self.known_params = config.get("__known_params", None)
        self.actor_wait = config.get("actor_wait", True)
        self.wait_time = config.get("wait_time", 2)
        self.max_reuse = config.get("max_reuse", 50)
        # Initialize the number concentration N if required
        if self.calc_init_N:
            self.opt_pbe.calc_init_from_data(self.exp_data_paths, init_flag='mean')
            
        # Store experimental data and known parameters
        self.pop_params = pop_params
        self.data_path = data_path
        self.exp_case = self.exp_data
        self.reuse_num =  0
        
        # Prepare experimental data (either for 1D or 2D)
        if isinstance(self.exp_data_paths, list):
            # When set to multi, the exp_data_paths entered here is a list containing one 2d data name and two 1d data names.
            x_uni_exp = []
            data_exp = []
            for exp_data_paths_tem in self.exp_data_paths:
                x_uni_exp_tem, data_exp_tem = self.p.get_all_data(exp_data_paths_tem)
                x_uni_exp.append(x_uni_exp_tem)
                data_exp.append(data_exp_tem)
        else:
            # When not set to multi or optimization of 1d-data, the exp_data_paths contain the name of that data.
            x_uni_exp, data_exp = self.p.get_all_data(self.exp_data_paths)
        self.x_uni_exp = x_uni_exp
        self.data_exp = data_exp
        
        self._time_loger = False
        if self._time_loger:
            self._logdir = self._resolve_logdir()
            self._csv = os.path.join(self.logdir, "timings_yappi.csv")
            print(f"save the info in path {self._csv}")
            if not os.path.exists(self._csv):
                with open(self._csv, "w", newline="") as f:
                    csv.writer(f).writerow([
                        "sample_idx","matrix_size",
                        "step_wall_s","solver_wall_s","overhead_wall_s"
                    ])
            self._sample_idx = 0
        
        self.EXCLUDE_KEYS = {"__exp_paths", "__known_params", "actor_wait", "wait_time", "max_reuse"}
    
    def step(self):
        """
        Perform one step of optimization.

        This method is called by Ray Tune to execute a single iteration of the optimization. 
        It calculates the loss (delta) between the experimental and simulated data based on 
        the current configuration parameters.

        Returns
        -------
        dict
            A dictionary containing the loss (delta) and the reuse count for the current Actor.
        """
        start_time = time.time()
        transformed_params = {k: deepcopy(v) for k, v in self.config.items() if k not in self.EXCLUDE_KEYS}
            
        if not self.exp_case:
            # Apply known parameters to override any conflicting optimization parameters
            if self.known_params is not None:
                for key, value in self.known_params.items():
                    if key in transformed_params:
                        print(f"Warning: Known parameter '{key}' are set for optimization.")
                    transformed_params[key] = value
                    
            # Transform the input parameters if they include corr_agg for dimensional handling
            if 'corr_agg_0' in transformed_params:
                transformed_params = self.array_dict_transform(transformed_params)   
            # print(f"The paramters actually entered calc_delta are {transformed_params}")
            if self._time_loger:
                matrix_size = int(transformed_params.get("matrix_size", -1))
                t0 = time.perf_counter()
                yappi.clear_stats()
                yappi.set_clock_type("wall")  # First measure wall clock (reflects waiting + Python layer overhead)
                yappi.start()
            
            # Calculate the loss (delta) using the transformed parameters
            loss = self.calc_delta(transformed_params, self.x_uni_exp, self.data_exp)
            if self._time_loger:
                yappi.stop()
                _yappi_debug_preview(keyword="calc_delta")
                solver_wall_s = _yappi_total_time(name_endswith=".calc_delta")
                step_wall_s = time.perf_counter() - t0
                overhead_wall_s = max(0.0, step_wall_s - solver_wall_s)
                with open(self._csv, "a", newline="") as f:
                    csv.writer(f).writerow([
                        self._sample_idx, matrix_size,
                        f"{step_wall_s:.6f}", f"{solver_wall_s:.6f}", f"{overhead_wall_s:.6f}"
                    ])
                self._sample_idx += 1
            
        else:
            losses = []
            for i in range(len(self.known_params)):
                known_i = self.known_params[i]
                for key, value in known_i.items():
                    transformed_params[key] = value
                # Transform the input parameters if they include corr_agg for dimensional handling
                if 'corr_agg_0' in transformed_params:
                    transformed_params = self.array_dict_transform(transformed_params)    
                # print(f"The paramters actually entered calc_delta are {transformed_params}")
                x_i = self.x_uni_exp[i]
                data_i = self.data_exp[i]
                loss_i = self.calc_delta(transformed_params, x_i, data_i)
                losses.append(loss_i)
            loss = sum(losses) / len(losses)
        
        end_time = time.time()
        execution_time = end_time - start_time
        
        # If execution time is too short, introduce a delay to simulate actor waiting
        # This is done because Ray Tune introduces a delay when managing and communicating between actors.
        # If the iteration is too fast, it may cause unknown errors where actors are repeatedly created
        # and discarded, leading to a large number of ineffective operations and impacting system performance.
        if execution_time < self.wait_time and self.actor_wait:
            time.sleep(self.wait_time - execution_time)
            
        result = {"loss": loss, "reuse_num": self.reuse_num, "exp_paths": self.exp_data_paths}    
        return result
    
    def save_checkpoint(self, checkpoint_dir):
        """
        Save the checkpoint. This method is required by Ray Tune but is not used in this implementation.
        """
        pass
    def load_checkpoint(self, checkpoint_path):
        """
        Load a checkpoint. This method is required by Ray Tune but is not used in this implementation.
        """
        pass
    def reset_config(self, new_config):
        """
        Reset the Actor for reuse in subsequent iterations.

        This method is called when Ray Tune needs to reset the Actor between iterations.
        The reuse counter is incremented each time this method is called.

        Returns
        -------
        bool
            Always returns True, indicating successful configuration reset.
        """
        self.reuse_num += 1
        if self.reuse_num >= self.max_reuse:
            self.opt_pbe.close_pbe()
            self.init_pbe(self.pop_params, self.data_path)
            if self.calc_init_N:
                self.opt_pbe.calc_init_from_data(self.exp_data_paths, init_flag='mean')
            self.reuse_num = 0
        self.config = new_config
        return True
        
    def _resolve_logdir(self) -> str:
        # 1) In Ray Tune's Trainable, self.logdir is already available (read-only)
        try:
            return str(self.logdir)
        except Exception:
            pass
        # 2) In functional/other contexts, use session/get_trial_dir as fallback
        try:
            from ray.air import session
            return str(session.get_trial_dir())
        except Exception:
            try:
                from ray import tune
                return str(tune.get_trial_dir())
            except Exception:
                # 3) Final fallback: current working directory
                return str(Path.cwd())
            
def _yappi_total_time(name_equals: str | None = None,
                      name_contains: str | None = None,
                      name_endswith: str | None = None,
                      module_contains: str | None = None,
                      use_self_time: bool = False) -> float:
    """
    Aggregate yappi statistics (in seconds).
    - name_equals / name_contains / name_endswith: Match yappi's function name field (e.g., "OptCoreMultiRay.calc_delta")
    - module_contains: Match module field (usually file path, on Windows can use 'opt_core_multi.py' or 'optframework' fragment)
    - use_self_time=True uses (ttot - tsub) for self time only; default uses ttot (including sub-calls)
    """
    total = 0.0
    stats = yappi.get_func_stats()
    for s in stats:
        name = (getattr(s, "name", "") or "")
        module = (getattr(s, "module", "") or "")
        if name_equals is not None and name != name_equals:
            continue
        if name_contains is not None and name_contains not in name:
            continue
        if name_endswith is not None and not name.endswith(name_endswith):
            continue
        if module_contains is not None and module_contains not in module:
            continue
        ttot = float(getattr(s, "ttot", 0.0) or 0.0)
        if use_self_time:
            tsub = float(getattr(s, "tsub", 0.0) or 0.0)
            ttot = max(0.0, ttot - tsub)
        total += ttot
    return total

def _yappi_debug_preview(limit: int = 50, keyword: str | None = None) -> None:
    """
    Print first several yappi statistics to identify the actual content of module/fullname.
    Call after yappi.stop() to see what entries are available.
    """
    stats = yappi.get_func_stats()
    cnt = 0
    for s in stats:
        name = getattr(s, "name", "")
        module = getattr(s, "module", "")
        fullname = getattr(s, "fullname", "")
        ttot = getattr(s, "ttot", 0.0)
        tsub = getattr(s, "tsub", 0.0)
        line = f"module={module} | fullname={fullname} | name={name} | ttot={ttot:.6f}s | self={max(0.0, ttot - tsub):.6f}s"
        if (keyword is None) or (keyword in line):
            print(line)
            cnt += 1
            if cnt >= limit:
                break